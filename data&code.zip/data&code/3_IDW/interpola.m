clear;
clc

filename='canshu.txt';
fid = fopen(filename,'r');
gk=fscanf(fid,'%f',[2,100])';
fclose(fid) ;


for ii=101:1:104

% if gk(ii,1)~=0&&gk(ii,2)~=0

filename1=strcat('patch_mesh_',num2str(ii),'(1).mat');

load(filename1);

n=length(coods_pre);
r=4;

min_position=knnsearch(coords_sim,coods_pre,'k',r);

for i=1:1:n
    for j=1:1:r
        distance_1(i,j)=sqrt((coods_pre(i,1)-coords_sim(min_position(i,j),1))^2+...
            (coods_pre(i,2)-coords_sim(min_position(i,j),2))^2+...
            (coods_pre(i,3)-coords_sim(min_position(i,j),3))^2);
        p_distance(i,j)=1/distance_1(i,j);
    end
    sum_p_distance(i,1)=sum(p_distance(i,:));
    T_pre(i,1)=0;
    for j=1:1:r
        T_pre(i,1)=T_pre(i,1)+T_sim(min_position(i,j),1)*p_distance(i,j)/sum_p_distance(i,1);
    end
end

T_PRE_3_26(:,ii-100)=T_pre;

% end

end

% T_PRE(:,all(T_PRE==0,1))=[];

% Variable_condition(:,all(Variable_condition(4,:)<0.05,1))=[];
% T_PRE(:,all(Variable_condition(4,:)<0.05,1))=[];
