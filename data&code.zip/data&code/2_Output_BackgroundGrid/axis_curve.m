function [x,y,z]=axis_curve(s)

length_line=[1289.05,1524*pi/2,152.4,1524*pi/2,4416.43,1524*pi/2,995.935,1524*61.5/180*pi,426.015]';  %mm
R=1524;  %弧半径

if s>=0&&s<length_line(1,1)    %1
    x=-1676.4;
    y=2813.05-s;
    z=0;

elseif s>=length_line(1,1)&&s<sum(length_line(1:2,1))     %2
    x=-152.4-R*cos((s-length_line(1,1))/R);
    y=1524-R*sin((s-length_line(1,1))/R);
    z=0;

elseif s>=sum(length_line(1:2,1))&&s<sum(length_line(1:3,1))    %3
    x=-152.4+(s-sum(length_line(1:2,1)));
    y=0;
    z=0;

elseif s>=sum(length_line(1:3,1))&&s<sum(length_line(1:4,1))   %4
    x=0+R*sin((s-sum(length_line(1:3,1)))/R);
    y=0;
    z=0+R-R*cos((s-sum(length_line(1:3,1)))/R);
    

elseif s>=sum(length_line(1:4,1))&&s<sum(length_line(1:5,1))    %5
    x=1524;
    y=0;
    z=1524+(s-sum(length_line(1:4,1))); 

elseif s>=sum(length_line(1:5,1))&&s<sum(length_line(1:6,1))    %6
    x=R*cos((s-sum(length_line(1:5,1)))/R);
    y=0;
    z=5940.43+R*sin((s-sum(length_line(1:5,1)))/R);
    

elseif s>=sum(length_line(1:6,1))&&s<sum(length_line(1:7,1))    %7
    x=-(s-sum(length_line(1:6,1)));
    y=0;
    z=7464.43;

elseif s>=sum(length_line(1:7,1))&&s<sum(length_line(1:8,1))    %8
    x=-995.94-R*sin((s-sum(length_line(1:7,1)))/R);
    y=0;
    z=8988.43-R*cos((s-sum(length_line(1:7,1)))/R);

elseif s>=sum(length_line(1:8,1))&&s<sum(length_line(1:9,1))        %9
    x=-2335.25-sin(28.5/180*pi)/1*(s-sum(length_line(1:8,1)));
    y=0;
    z=8261.24+cos(28.5/180*pi)/1*(s-sum(length_line(1:8,1)));
        

end
end
