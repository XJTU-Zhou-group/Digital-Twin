function [x1,y1,z1,x2,y2,z2,x3,y3,z3]=pointer_vector(s)

length_line=[1289.05,1524*pi/2,152.4,1524*pi/2,4416.43,1524*pi/2,995.935,1524*61.5/180*pi,426.015]';  %mm
R=1524;  %弧半径

x1=1;
y1=0;
z1=0;


if s>=0&&s<length_line(1,1)           %1
    x3=0;
    y3=-1;
    z3=0;

    x1=1;
    y1=0;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);


elseif s>=length_line(1,1)&&s<sum(length_line(1:2,1))        %2
    x3=sin((s-length_line(1,1))/R);
    y3=-cos((s-length_line(1,1))/R);
    z3=0;

    x1=1*cos((s-length_line(1,1))/R);
    y1=1*sin((s-length_line(1,1))/R);
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);

elseif s>=sum(length_line(1:2,1))&&s<sum(length_line(1:3,1))                      %3
    x3=1;
    y3=0;
    z3=0;

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);

elseif s>=sum(length_line(1:3,1))&&s<sum(length_line(1:4,1))                       %4
    x3=cos((s-sum(length_line(1:3,1)))/R);
    y3=0;
    z3=sin((s-sum(length_line(1:3,1)))/R);

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);
    

elseif s>=sum(length_line(1:4,1))&&s<sum(length_line(1:5,1))                 %5
    x3=0;
    y3=0;
    z3=1;

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);

elseif s>=sum(length_line(1:5,1))&&s<sum(length_line(1:6,1))                    %6
    x3=-sin((s-sum(length_line(1:5,1)))/R);
    y3=0;
    z3=cos((s-sum(length_line(1:5,1)))/R);

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);
    

elseif s>=sum(length_line(1:6,1))&&s<sum(length_line(1:7,1))               %7
    x3=-1;
    y3=0;
    z3=0;

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);

elseif s>=sum(length_line(1:7,1))&&s<sum(length_line(1:8,1))                 %8
    x3=-cos((s-sum(length_line(1:7,1)))/R);
    y3=0;
    z3=sin((s-sum(length_line(1:7,1)))/R);

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);

elseif s>=sum(length_line(1:8,1))&&s<sum(length_line(1:9,1))                %9
    x3=-sin(28.5/180*pi);
    y3=0;
    z3=cos(28.5/180*pi);

    x1=0;
    y1=1;
    z1=0;

    A=cross([x3,y3,z3],[x1,y1,z1]);

    x2=A(1);
    y2=A(2);
    z2=A(3);
        

end
end