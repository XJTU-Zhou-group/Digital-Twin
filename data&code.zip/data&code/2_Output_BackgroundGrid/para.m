function [x_node,y_node,z_node]=para(R_inner,theta,I)
%% 
% 输入参数 内径 角度（仅限绕原点x轴，逆时针旋转）

%R_inner=106.6453555; theta=12.36802738; %单位mm，度数。

%%
%         %参数方程
%         s=[0:0.01:4];
%         x=1*cos(s./1);
%         y=1*sin(s./1);
%         plot(x,y);
%         
%         %八个分段函数


num_mesh=[12,24,2,24,44,24,10,16,4]';  %布置网格沿轴线方向上的单元数
length_line=[1289.05,1524*pi/2,152.4,1524*pi/2,4416.43,1524*pi/2,995.935,1524*61.5/180*pi,426.015]';  %mm
length_cell=length_line./num_mesh;

num_node=sum(num_mesh)+1;
mesh_node=num_node*48;
mesh_cell=sum(num_mesh)*48;
s_line=zeros(num_node,1);
x_line=zeros(num_node,1);
y_line=zeros(num_node,1);
z_line=zeros(num_node,1);

[x_line(1),y_line(1),z_line(1)]=axis_curve(s_line(1));


k=1;
for i=1:9
    
    for j=1:num_mesh(i)
        s_line(k+1)=s_line(k)+length_cell(i);
        [x_line(k+1),y_line(k+1),z_line(k+1)]=axis_curve(s_line(k+1));
        
        k=k+1;
    end

end

plot3(x_line,y_line,z_line,'.');


%% 
% 圆等分48份
x_circle=zeros(48,1);
y_circle=zeros(48,1);

x_circle(1)=1;
y_circle(1)=0;
for  i=1:48-1
    x_circle(i+1)=cos(2*pi/48*(i));
    y_circle(i+1)=sin(2*pi/48*(i));

end
plot(x_circle,y_circle,'*');


%%
%节点坐标
x_node=zeros(num_node*48,1);
y_node=zeros(num_node*48,1);
z_node=zeros(num_node*48,1);

k_node=1;
for i=1:161

    for j=1:48
        [x1,y1,z1,x2,y2,z2,x3,y3,z3]=pointer_vector(s_line(i));
        corr_node=[x_line(i),y_line(i),z_line(i)]+R_inner*x_circle(j).*[x1,y1,z1]+R_inner*y_circle(j).*[x2,y2,z2];
        x_node(k_node)=corr_node(1);
        y_node(k_node)=corr_node(2);
        z_node(k_node)=corr_node(3);

        k_node=k_node+1;



    end

end

%plot3(x_node,y_node,z_node,'.');

%% 
% 单元序号

element_set=zeros(160*48,4);
k_element=1;
for i=1:160
    for j=1:48

        element_set(k_element,1)=(i-1)*48+j  ;
        element_set(k_element,2)=i*48+j  ;
        element_set(k_element,3)=i*48+j+1 ; 
        element_set(k_element,4)=(i-1)*48+j+1;

        if j==48
            element_set(k_element,1)=(i-1)*48+j  ;
            element_set(k_element,2)=i*48+j  ;
            element_set(k_element,3)=i*48+1 ; 
            element_set(k_element,4)=(i-1)*48+1;
        end

        k_element=k_element+1;

    end

end

%% 缩放 
x_node=x_node/1000;
y_node=y_node/1000;
z_node=z_node/1000;

%% 旋转 仅限坐标原点绕x轴旋转
start_node=sum(num_mesh(1:3,1))*48+1;
theta2=theta/180*pi;
yz_coor=[y_node(start_node:mesh_node,1),z_node(start_node:mesh_node,1)]';
rotation=[cos(theta2), -sin(theta2);sin(theta2), cos(theta2)];
yz_coor=rotation*yz_coor;

y_node(start_node:mesh_node,1)=yz_coor(1,:)';
z_node(start_node:mesh_node,1)=yz_coor(2,:)';


        %% 写成网格形式  输出排序
        order=[1:mesh_cell]';
        
        %filename=strcat('yy_R',num2str(R_inner),'theta',num2str(theta2),'.dat');
        filename=strcat('yy',num2str(I),'.dat');
        fid=fopen(filename,'w');             % file name
        fprintf(fid,'TITLE     = "Tecplot Export" \n');    % parameters to export
        fprintf(fid,'VARIABLES = "CoordinateX" \n');
        fprintf(fid,'"CoordinateY" \n');
        fprintf(fid,'"CoordinateZ" \n');
        fprintf(fid,'"order" \n');

        zonename=strcat('ZONE T="interface',num2str(I),'" \n');

        fprintf(fid,zonename);
        fprintf(fid,' STRANDID=5, SOLUTIONTIME=600 \n');
        fprintf(fid,' Nodes=%.0f, Elements=%.0f, ZONETYPE=FEQuadrilateral \n',mesh_node,mesh_cell);
        fprintf(fid,' DATAPACKING=BLOCK \n');  % VARLOCATION=([4]=CELLCENTERED)
        fprintf(fid,' VARLOCATION=([4]=CELLCENTERED) \n');
        fprintf(fid,' AUXDATA Time="');
        fprintf(fid,'%.6e',600);
        fprintf(fid,'" \n');
        fprintf(fid,' DT=(SINGLE SINGLE SINGLE SINGLE ) \n');
        fprintf(fid,'%.18e %.18e %.18e \n',x_node(:,1));
        fprintf(fid,'%.18e %.18e %.18e \n',y_node(:,1));
        fprintf(fid,'%.18e %.18e %.18e \n',z_node(:,1));
        fprintf(fid,'%.18e %.18e %.18e \n',order(:,1));
        fprintf(fid,'%.0f %.0f %.0f %.0f \n',element_set');
        fclose(fid);


end
























