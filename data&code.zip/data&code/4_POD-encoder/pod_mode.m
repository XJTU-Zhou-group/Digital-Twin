clear
clc


load('T_PRE1.mat');

snap=T_PRE;

[PHI,D,V] = svd(snap,'econ');

r=20;

    Lamd=diag(D);
    
    All=sum(Lamd);
    
    for i=1:r
        B(i,1)=sum(Lamd(1:i,1))/All;
        B1(i,1)=1-B(i,1);
        B1(i,2)=i;
    end


DATA=PHI(:,1:r)*D(1:r,1:r)*V(:,1:r)';

q=D(1:r,1:r)*V(:,1:r)';

% % n=1;
% % for t=450:10:750
% % 
% x5=[169.853133900000 38.5985416000000 8.40836845000000 0.0797791712918239 52.2060782832500];
% x23=[208.492465200000 17.9432247000000 1.19089644000000 0.0994083739547660 62.7099994406780];
% % x=[0.08 120 t];
% q_neural5=myNeuralNetworkFunction1(x5');
% q_neural23=myNeuralNetworkFunction1(x23');
% % % 
% Predict_5=PHI(:,1:r)*q_neural5;
% Predict_23=PHI(:,1:r)*q_neural23;
% % 
% % n=n+1;
% % 
% % end
% % 


    figure;
    semilogy(B1(1:20,2),B1(1:20,1),'-bo','linewidth',2.5,'MarkerSize',6,'MarkerEdgeColor','r','MarkerFaceColor','r');
    xlim([1,20]);
%     ylim([0.0001,0.01]);
    set(gcf,'Position',[300 500 400 300]);
    set(gca,'FontName','Times New Roman','FontSize',18,'FontWeight','bold'); 
    set(gca,'linewidth',3);

% 
% plot(temperature(:,1))
% hold on
% plot(Predict)