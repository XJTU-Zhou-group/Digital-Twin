The function "raed_sim.m" is a MATLAB function for reading calculation results, 
where "i" represents the index number of the simulation result.