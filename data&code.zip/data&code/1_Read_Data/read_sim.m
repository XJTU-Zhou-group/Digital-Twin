function [coords_sim,T_sim]=read_sim(I)
% clear all;
% clc;
% I=1;
filename =strcat(num2str(I),'.dat');
fid = fopen(filename,'r');
for l=1:8  % Ignoring starting lines
    cur_line = fgets(fid);%当前cur_line为第四行字符串
end

mesh_info=regexp(cur_line,'\d*\.?\d*','match');
mesh_num=str2double(mesh_info);
number_nodes=mesh_num(1,1);
number_E=mesh_num(1,2);

for l=1:3  % Ignoring starting lines
    cur_line = fgets(fid);%当前cur_line为第四行字符串
end

coords_sim=fscanf(fid,'%f',[number_nodes,3]);
T_sim=fscanf(fid,'%f',[number_nodes,1]);

element_sim  = fscanf(fid,'%d',[4,number_E])';
fclose(fid) ;       % Reading Mesh completed


end