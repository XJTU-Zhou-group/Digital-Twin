"Sim_main.m" is the main program with two output modes: 
Mode 1（mode_switch=1） only outputs background grid files, "yyi.dat" (a Tecplot file) and "patch_mesh_i.mat" (a MATLAB file); 
Mode 2 (mode_switch=2)  reads the predicted results from the POD-ANN hybrid method and outputs post-processing files.

The function "para_write_sim.m" outputs post-processing files for simulation results, 
while "para_write_pre.m" outputs post-processing files for prediction results. 
The post-processing files can be opened with Tecplot.