clear all;
clc;

%%
filename='canshu.txt';
fid = fopen(filename,'r');
gk=fscanf(fid,'%f',[2,113])';
fclose(fid) ;

mode_switch=2;

switch mode_switch
    case 1

        %for i=1:113
        i=5;
            if gk(i,1)~=0&&gk(i,2)~=0
                [coords_sim,T_sim]=read_sim(i);
                
                % prediction main
                [X,Y,Z]=para(gk(i,1),gk(i,2),i);
                coods_pre=[X,Y,Z];
        
                filename2=strcat('patch_mesh_',num2str(i),'.mat');
                save(filename2,'coords_sim','T_sim','coods_pre');
                
            end
        %end

    case 2
        i=5
        
        filename_pre=strcat('Pre_',num2str(i),'_2.mat');
        filename_sim=strcat('Sim_',num2str(i),'_2.mat');
        Temp_pre=importdata(filename_pre);
        Temp_sim=importdata(filename_sim);
        Temprature_pre=Temp_pre(:,1);
        Temprature_sim=Temp_sim(:,1);
        para_write_pre(gk(i,1),gk(i,2),i,Temprature_pre);
        para_write_sim(gk(i,1),gk(i,2),i,Temprature_sim);
        para_write_error(gk(i,1),gk(i,2),i,abs(Temprature_sim-Temprature_pre));


end
    





