clear
clc

load('T_PRE1.mat');

snap=T_PRE;

[PHI,D,V] = svd(snap,'econ');

r=10;

    Lamd=diag(D);
    
    All=sum(Lamd);
    
    for i=1:r
        B(i,1)=sum(Lamd(1:i,1))/All;
        B1(i,1)=1-B(i,1);
        B1(i,2)=i;
    end


DATA=PHI(:,1:r)*D(1:r,1:r)*V(:,1:r)';

q=D(1:r,1:r)*V(:,1:r)';

% n=1;
% for t=450:10:750

% load('pre_var.mat');
% 
% n_pre=size(pre_var,1);

load('T_PRE_3_25.mat');
% load('T_PRE.mat');

% load('Variable_condition');

% load('Pre_var_3_26.mat');

load('Pre_var_3_25.mat');


for i=2


x=pre_var(i,:);
% x=Variable_condition(:,i);


q_neural(:,i)=myNeuralNetworkFunction1(x');
 
T_Predict(:,i)=PHI(:,1:r)*q_neural(:,i);

% T_tru(:,i)=T_PRE(:,i);
% T_tru(:,i)=T_PRE_beta(:,i);
% T_tru(:,i)=T_PRE_pre(:,i);
T_tru(:,i)=T_PRE_pre(:,i);


p1=T_tru(:,i);
p2=T_Predict(:,i);
p_mean=mean(p1);
R_w(i)=1-(sum((p1-p2).^2))/(sum((p1-p_mean).^2));


end


% end

% n=n+1;

% end
